/**
 * <Signifies that the Java class "Car" is implementing the "Comparable" interface with the generic type "Car".>
 *
 * CSC 1351 Programming Project No <1 Part A>
 7
 * Section <002>
 *
 * @author <Caleb Basnight>
 * @since <10/31/2023>
 *
 */

public class Car implements Comparable<Car> {
    private String make;
    private int year;
    private int price;

    /**
     * <Specifies the make, year, and price of the Car class>
     *
     * CSC 1351 Programming Project No <1 Part A>
     * Section <002>
     *
     * @author <Caleb Basnight>
     * @since <10/31/2023>
     *
     */
    public Car(String Make, int Year, int Price) {
        make = Make;
        year = Year;
        price = Price;
    }
    /**
     * <Returns a string value representing the "make" attribute of an object.>
     *
     * CSC 1351 Programming Project No <1 Part A>
     * Section <002>
     *
     * @author <Caleb Basnight>
     * @since <10/31/2023>
     *
     */

    public String getMake() {
        return make;
    }
    /**
     * <Returns an integer value representing the "year" attribute of an object.>
     *
     * CSC 1351 Programming Project No <1 Part A>
     * Section <002>
     *
     * @author <Caleb Basnight>
     * @since <10/31/2023>
     *
     */

    public int getYear() {
        return year;
    }
    /**
     * <Returns an integer value representing the "price" attribute of an object.>
     *
     * CSC 1351 Programming Project No <1 Part A>
     * Section <002>
     *
     * @author <Caleb Basnight>
     * @since <10/31/2023>
     *
     */

    public int getPrice() {
        return price;
    }
    /**
     * <Allows for the comparison and ordering of Car objects primarily based on their make, and in case of equal makes, it further considers their year and price attributes for comparison.>
     *
     * CSC 1351 Programming Project No <1 Part A>
     * Section <002>
     *
     * @author <Caleb Basnight>
     * @since <10/31/2023>
     *
     */

    public int compareTo(Car other) {
        if (!make.equals(other.make)) {
            return make.compareTo(other.make);
        } else if (year != other.year) {
            return year - other.year;
        } else {
            return price - other.price;
        }
    }
    /**
     * <Provides a string representation of a Car object.>
     *
     * CSC 1351 Programming Project No <1 Part A>
     * Section <002>
     *
     * @author <Caleb Basnight>
     * @since <10/31/2023>
     *
     */

    public String toString() {
        return "Make: " + make + ", Year: " + year + ", Price: " + price + ";";
    }





}
