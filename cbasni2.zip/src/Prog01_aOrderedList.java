import java.io.FileNotFoundException;
import java.util.*;
import java.io.PrintWriter;
import java.io.File;
/**
 * <Contains a partially filled array>
 *
 * CSC 1351 Programming Project No <1 Part A>
 7
 * Section <002>
 *
 * @author <Caleb Basnight>
 * @since <10/31/2023>
 *
 */
public class Prog01_aOrderedList {
    /**
     * <Gets the InputFile and  obtains a Scanner object for reading data from an input file.>
     *
     * CSC 1351 Programming Project No <1 Part A>
     * Section <002>
     *
     * @author <Caleb Basnight>
     * @since <10/31/2023>
     *
     */
    public static Scanner GetInputFile(String UserPrompt) throws FileNotFoundException {
        //PrintWriter outFile = new PrintWriter("car.txt");
         // outFile.close();

        File inputFile = new File("car.txt");
        Scanner in = new Scanner(inputFile);

        Scanner scanner = null;

        while (scanner == null) {
            System.out.print(UserPrompt + "Enter input filename: ");
            String fileName = new Scanner(System.in).nextLine();

            if (fileName.equalsIgnoreCase("N")) {
                throw new FileNotFoundException("Program execution canceled.");
            }

            if (fileName.startsWith(".\\")) {
                fileName = fileName.substring(2);
            }

            File file = new File(fileName);
            System.out.println("Filename" + file);
            if (file.exists()) {
                System.out.println("Makescanner");
                scanner = new Scanner(file);
            } else {
                System.out.println("File not found. Please enter a valid file name or path.");
            }
        }
        System.out.println("Scanner" + scanner);
        return scanner;
    }
    /**
     * <Gets the OutputFile and obtains a PrintWriter object for writing data to a file.>
     *
     * CSC 1351 Programming Project No <1 Part A>
     * Section <002>
     *
     * @author <Caleb Basnight>
     * @since <10/31/2023>
     *
     */
    public static PrintWriter getOutputFile(String userPrompt) throws FileNotFoundException {
        PrintWriter writer = null;

        while (writer == null) {
            System.out.print(userPrompt + ": ");
            String fileName = new Scanner(System.in).nextLine();

            if (fileName.equalsIgnoreCase("N")) {
                throw new FileNotFoundException("Program execution canceled.");
            }

            if (fileName.startsWith(".\\")) {
                fileName = fileName.substring(2);
            }

            File file = new File(fileName);

            try {
                writer = new PrintWriter(file);
            } catch (FileNotFoundException e) {
                System.out.println("File specified <" + fileName + "> is incorrect. Would you like to continue? <Y/N>");
                String response = new Scanner(System.in).nextLine().trim();
                if (response.equalsIgnoreCase("N")) {
                    throw new FileNotFoundException("Program execution canceled.");
                }
            }
        }

        return writer;
    }
    /**
     * <The main method of the aOrderList program.>
     *
     * CSC 1351 Programming Project No <1 Part A>
     * Section <002>
     *
     * @author <Caleb Basnight>
     * @since <10/31/2023>
     *
     */

    public static void main(String args[]) {
        //List<Car> carList = new ArrayList<>();

        aOrderedList carList = new aOrderedList();

        try {
            Scanner inputFileScanner = GetInputFile( "");
            //System.out.println("gotscanner");
            while (inputFileScanner.hasNextLine()) {
                //System.out.println("Readingnextline");
                String line = inputFileScanner.nextLine();
                System.out.println("Line" + line );
                String[] parts = line.split(",");
                if (parts.length == 4 && parts[0].equals("A")) {
                    // "A" == "add"
                    String make = parts[1];
                    int year = Integer.parseInt(parts[2]);
                    int price = Integer.parseInt(parts[3]);
                    Car car = new Car(make, year, price);
                    carList.add(car);
                }
                /*
                if (parts.length == 2 && parts[0].equals("D")) {
                    // "D" == "delete"
                    System.out.println("Delete: " + parts[1]);
                    int index = Integer.parseInt(parts[1]);
                    carList.remove(index);
                }
                 */
                if (parts.length == 3 && parts[0].equals("D")) {
                    // "D" == "delete"
                    System.out.println("Delete: " + parts[1]);
                    String make = parts[1];
                    int year = Integer.parseInt(parts[2]);
                    carList.reset();
                    while (carList.hasNext()) {
                        Car car =(Car) carList.next();
                        if(car.getMake().equals(make) && car.getYear() == year)
                        {
                            System.out.println("Found car to delete");
                            carList.remove();
                            break;
                        }
                    }
                }
            }
            inputFileScanner.close();
            System.out.println("Car Lists");
            System.out.println(carList);

            //Output the contents of the array formatted
            System.out.println("NumberofCars: " + carList.size() + "\n");

            //Loops through carsarray

            for(int i = 0; i < carList.size(); i++) {
                Car car =(Car) carList.get(i);
                System.out.printf("Make: %15s \n", car.getMake());
                System.out.printf("Year: %15d \n", car.getYear());
                System.out.printf("Price: %,15d \n\n", car.getPrice());
            }

        } catch (FileNotFoundException e) {
            System.out.println("File not found or program execution canceled.");
        }

        try {

            PrintWriter outputFile = getOutputFile("Enter the filename of the output file");
            System.out.println("Writetooutputfile: " + outputFile);
            outputFile.println(carList.toString());

            outputFile.close();
        }

        catch (FileNotFoundException e) {
            System.out.println("Program execution canceled.");
        }
    }
}

