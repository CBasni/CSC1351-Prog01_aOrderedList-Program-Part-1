/**
 * <Provides a convenient way to manage and manipulate a sorted list of Car objects, allowing for the addition of new cars while keeping the list in a sorted order.>
 *
 * CSC 1351 Programming Project No <1 Part A>
 7
 * Section <002>
 *
 * @author <Caleb Basnight>
 * @since <10/31/2023>
 *
 */

public class aOrderedList {
    private final int SIZEINCREMENTS = 5;
    private Comparable[] oList;
    private int listSize;
    private int numObjects;

    private int curr; //index of current element accessed via
    //iterator methods

    public aOrderedList() {
        numObjects = 0;
        listSize = SIZEINCREMENTS;
        oList = new Car[listSize];
    }
    public void add(Comparable newCar) {
        if (numObjects == listSize) {
            System.out.println("OldSizeIs: " + numObjects + " " + oList.length);
            listSize += SIZEINCREMENTS;
            Car[] newArray = new Car[listSize];
            System.arraycopy(oList, 0, newArray, 0, numObjects);
            oList = newArray;
            System.out.println("OldSizeIs: " + oList.length);

        }

        int insertIndex = numObjects;
        while (insertIndex > 0 && newCar.compareTo(oList[insertIndex - 1]) < 0) {
            oList[insertIndex] = oList[insertIndex - 1];
            insertIndex--;
        }

        oList[insertIndex] = newCar;
        numObjects++;
    }
    //returns the number of elements in the list
    public int size(){
        return numObjects;
    }
    //returns the element at the specified position in the list
    public Comparable get(int index) {
        if(index < 0 || index >= numObjects){
            return null;
        }
        else{
            return oList[index];
        }
    }
    //Returns true if the array is empty and false otherwise.
    public boolean isEmpty(){
        return numObjects == 0;
    }
    //Removes the element at the specified position in this list.
    public void remove(int index) {
        if(index < 0 || index >= numObjects) {
            return;
        }
        else{
            System.out.println("Remove at index " + index);
            for(int i = index; i < numObjects - 1; i++) {
                oList[i] = oList[i + 1];
            }
            numObjects--;
        }
    }
    //Resets iterator parameters so that the "next" element is the first e
    public void reset(){
        curr = 0;
    }

    //Returns the next element in the iteration and increments the iterator parameters
    public Comparable next() {
        Comparable car = oList[curr];
        curr++;
        return car;
    }

    //Returns true if the iteration has more elements to iterate through

    public boolean hasNext() {
        if (curr < numObjects) {
            return true;
        } else {
            return false;
        }
    }

    //Removes the last element returned by the next() method

    public void remove() {
        System.out.println("Iterator remove at index: " + curr);
        remove(curr - 1);
    }


    @Override
    public String toString() {
        StringBuilder result = new StringBuilder("[");
        for (int i = 0; i < numObjects; i++) {
            result.append(oList[i].toString());
            if (i < numObjects - 1) {
                result.append(", ");
            }
        }
        result.append("]");
        return result.toString();
    }

}
